DROP DATABASE `inventario`

CREATE DATABASE `inventario`

