package com.iesvdc.acceso.inventario;

public class ConexOracle {
    public static void main(String[] args) {

    }
}
