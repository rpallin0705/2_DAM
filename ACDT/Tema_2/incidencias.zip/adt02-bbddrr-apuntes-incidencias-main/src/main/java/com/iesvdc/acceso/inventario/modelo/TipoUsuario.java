package com.iesvdc.acceso.inventario.modelo;

public enum TipoUsuario {
    ADMIN, USUARIO , OPERARIO
}
