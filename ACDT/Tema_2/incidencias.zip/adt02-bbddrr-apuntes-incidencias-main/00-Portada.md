---
title: "Programación de bases de datos relacionales"
author: [Juan Gualberto]
date: "Noviembre 2023"
keywords: [computación, Acceso a Datos, Java, marshalling, algoritmo, unmarshalling]
lang: "es"
titlepage: true,
titlepage-text-color: "FFFFFF"
titlepage-rule-color: "360049"
titlepage-rule-height: 0
titlepage-background: "docs/background.pdf"
toc: false
---

\pagebreak
\tableofcontents
\pagebreak
