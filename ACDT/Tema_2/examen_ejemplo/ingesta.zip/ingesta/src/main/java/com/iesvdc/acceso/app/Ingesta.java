package com.iesvdc.acceso.app;

/**
 * Hello world!
 *
 */
public class Ingesta 
{
    public static void main( String[] args )
    {
        System.out.println( "\n ····----++++===******===++++----·····\n");
        System.out.println("Aquí vamos a hacer la carga del archivo: " + args[0]);
        System.out.println(
            "Puedes cambiar el parámetro en el pom.xml, \n"+
            "busca el nombre del archivo y pon el archivo que necesites.");
        System.out.println( "\n ····----++++===******===++++----·····\n");
    }

}
