package com.iesvdc.acceso.app.model;

import java.time.LocalTime;
import java.util.Objects;

public class Horario {
    private int id;
    private int instalacion;
    private LocalTime inicio;
    private LocalTime fin;


    public Horario() {
    }

    public Horario(int id, int instalacion, LocalTime inicio, LocalTime fin) {
        this.id = id;
        this.instalacion = instalacion;
        this.inicio = inicio;
        this.fin = fin;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInstalacion() {
        return this.instalacion;
    }

    public void setInstalacion(int instalacion) {
        this.instalacion = instalacion;
    }

    public LocalTime getInicio() {
        return this.inicio;
    }

    public void setInicio(LocalTime inicio) {
        this.inicio = inicio;
    }

    public LocalTime getFin() {
        return this.fin;
    }

    public void setFin(LocalTime fin) {
        this.fin = fin;
    }

    public Horario id(int id) {
        setId(id);
        return this;
    }

    public Horario instalacion(int instalacion) {
        setInstalacion(instalacion);
        return this;
    }

    public Horario inicio(LocalTime inicio) {
        setInicio(inicio);
        return this;
    }

    public Horario fin(LocalTime fin) {
        setFin(fin);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Horario)) {
            return false;
        }
        Horario horario = (Horario) o;
        return id == horario.id && instalacion == horario.instalacion && Objects.equals(inicio, horario.inicio) && Objects.equals(fin, horario.fin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, instalacion, inicio, fin);
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", instalacion='" + getInstalacion() + "'" +
            ", inicio='" + getInicio() + "'" +
            ", fin='" + getFin() + "'" +
            "}";
    }
    
}
