package com.iesvdc.acceso.app;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.iesvdc.acceso.app.model.Instalacion;
import com.iesvdc.acceso.app.model.Usuario;
import com.iesvdc.acceso.app.service.InstalacionService;
import com.iesvdc.acceso.app.service.UsuarioService;

public class Main {
    public static void main(String[] args) {

        UsuarioService usuarioService = new UsuarioService();
        InstalacionService instalacionService = new InstalacionService();

        try (FileInputStream fis = new FileInputStream("reservas.xlsx")) {

            XSSFWorkbook wb = new XSSFWorkbook(fis);
            int nSheets = wb.getNumberOfSheets();

            for (int i = 0; i < nSheets; i++) {
                Sheet sheet = wb.getSheetAt(i);
                String sheetName = sheet.getSheetName();
                System.out.println(sheet.getSheetName());

                int firstRow = sheet.getFirstRowNum();
                int lastRow = sheet.getLastRowNum();

                for (int j = firstRow + 1; j <= lastRow; j++) {
                    Row row = sheet.getRow(j);
                    int firstCell = row.getFirstCellNum();
                    int lastCell = row.getLastCellNum();

                    switch (sheetName) {
                        case "usuario" -> {
                            Usuario usuario = new Usuario(
                                    row.getCell(1).getStringCellValue(),
                                    row.getCell(2).getStringCellValue(),
                                    row.getCell(3).getStringCellValue());
                            usuarioService.save(usuario);
                            break;
                        }

                        case "instalacion" -> {
                            Instalacion instalacion = new Instalacion(
                                    row.getCell(1).getStringCellValue());
                            instalacionService.save(instalacion);
                        }

                        default -> {
                            break;
                        }

                    }

                }
            }

            wb.close();

        } catch (IOException ioe) {
            System.out.println(ioe.getMessage());
        }

    }

    // private static void cargarDatos() {
    // try (FileInputStream fis = new FileInputStream("data.xlsx")){

    // XSSFWorkbook wb = new XSSFWorkbook(fis);

    // Sheet sheet = wb.getSheetAt(0);

    // Vehiculo vh = new Vehiculo();

    // for (int i = 2; i < 15; i++) {
    // Row row = sheet.getRow(i);

    // vh.marca(row.getCell(2).toString())
    // .modelo(row.getCell(3).getStringCellValue())
    // .anio(((int)row.getCell(3).getNumericCellValue()))
    // .modelo(row.getCell(4).getStringCellValue())
    // .modelo(row.getCell(5).getStringCellValue());

    // }

    // }catch (IOException e){
    // e.getMessage();
    // }
    // }
}
