package com.iesvdc.acceso.app.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.iesvdc.acceso.app.db.Conexion;
import com.iesvdc.acceso.app.model.Instalacion;
import com.iesvdc.acceso.app.model.Reserva;
import com.iesvdc.acceso.app.repository.ReservaRepository;

public class ReservaService implements ReservaRepository{

    private static final String SAVE_QUERY = "INSERT INTO Reserva (usuario, horario, fecha) VALUES (?)";
    private static final String FIND_ALL_QUERY = "SELECT * FROM Reserva";


     private Connection conn;

    public ReservaService() {
        this.conn = Conexion.getConnection();
    }

    @Override
    public Reserva save(Reserva reserva) {
        try (PreparedStatement ps = conn.prepareStatement(SAVE_QUERY, PreparedStatement.RETURN_GENERATED_KEYS)) {
            
            // Asignamos los parámetros del PreparedStatement con los datos del objeto vehiculo
            ps.setInt(1, reserva.getUsuario());
            ps.setInt(1, reserva.getUsuario());
            ps.setString(1, reserva.getFecha().toString());
    
    
            // Ejecutamos la consulta
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                // Si se insertó al menos una fila, obtenemos el ID generado
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        reserva.setId(generatedKeys.getInt(1));
                    }
                }
                System.out.println("Se insertaron " + rowsAffected + " filas.");
            } else {
                System.out.println("No se insertó ningún vehículo.");
            }
    
            // Retornamos el vehículo guardado con el ID asignado
            return reserva;
    
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Reserva> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

}
