package com.iesvdc.acceso.app.repository;

import java.util.List;

import com.iesvdc.acceso.app.model.Usuario;

public interface UsuarioRepository {
    Usuario save(Usuario Usuario);
    List<Usuario> findAll();
}
