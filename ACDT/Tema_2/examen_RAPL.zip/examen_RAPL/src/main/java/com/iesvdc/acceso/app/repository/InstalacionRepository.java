package com.iesvdc.acceso.app.repository;

import java.util.List;

import com.iesvdc.acceso.app.model.Instalacion;
import com.iesvdc.acceso.app.model.Instalacion;

public interface InstalacionRepository {
    Instalacion save(Instalacion instalacion);

    List<Instalacion> findAll();
}
