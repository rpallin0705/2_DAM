package com.iesvdc.acceso.app.repository;

import java.util.List;

import com.iesvdc.acceso.app.model.Reserva;

public interface ReservaRepository {
    Reserva save(Reserva reserva);
    List<Reserva> findAll();
}
