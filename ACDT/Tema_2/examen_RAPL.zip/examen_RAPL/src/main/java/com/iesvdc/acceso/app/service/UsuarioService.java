package com.iesvdc.acceso.app.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.iesvdc.acceso.app.db.Conexion;
import com.iesvdc.acceso.app.model.Usuario;
import com.iesvdc.acceso.app.repository.UsuarioRepository;

public class UsuarioService implements UsuarioRepository {

    private static final String SAVE_QUERY = "INSERT INTO Usuario (username, passwd, email) VALUES (?, ?, ?)";
    private static final String FIND_ALL_QUERY = "SELECT * FROM Usuario";

    private Connection conn;

    public UsuarioService() {
        this.conn = Conexion.getConnection();
    }

    @Override
    public Usuario save(Usuario usuario) {

        try (PreparedStatement ps = conn.prepareStatement(SAVE_QUERY, PreparedStatement.RETURN_GENERATED_KEYS)) {
            
            // Asignamos los parámetros del PreparedStatement con los datos del objeto vehiculo
            ps.setString(1, usuario.getUsername());
            ps.setString(2, usuario.getPasswd());
            ps.setString(3, usuario.getEmail());
    
    
            // Ejecutamos la consulta
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                // Si se insertó al menos una fila, obtenemos el ID generado
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        usuario.setId(generatedKeys.getInt(1));
                    }
                }
                System.out.println("Se insertaron " + rowsAffected + " filas.");
            } else {
                System.out.println("No se insertó ningún vehículo.");
            }
    
            // Retornamos el vehículo guardado con el ID asignado
            return usuario;
    
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    

    @Override
    public List<Usuario> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

}
