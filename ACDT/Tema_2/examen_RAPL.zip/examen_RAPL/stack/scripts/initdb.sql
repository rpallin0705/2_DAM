CREATE DATABASE IF NOT EXISTS reservas;

USE reservas;

CREATE TABLE Usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    passwd VARCHAR(65) NOT NULL,
    email VARCHAR(65) NOT NULL
);

CREATE TABLE Instalacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50)
);

CREATE TABLE Horario(
    id INT AUTO_INCREMENT PRIMARY KEY,
    instalacion INT,
    inicio DATE,
    fin DATE,
    FOREIGN KEY (instalacion) REFERENCES Instalacion(id) ON DELETE SET NULL
);

CREATE TABLE Reserva (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario INT,
    horario INT,
    fecha DATE,
    FOREIGN KEY (usuario) REFERENCES Usuario(id) ON DELETE SET NULL,
    FOREIGN KEY (horario) REFERENCES Horario(id) ON DELETE SET NULL
);

