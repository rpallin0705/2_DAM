# Acceso a Datos: Examen Tema 1

|  Nombre  | Apellidos | Fecha | Módulo |
|----------|---------- |-------| ---------- |
| Rafael Álvaro | Palomares Linares | Martes 15 de octubre | DAM: Acceso a datos |


