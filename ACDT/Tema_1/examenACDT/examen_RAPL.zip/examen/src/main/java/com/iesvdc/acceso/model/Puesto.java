package com.iesvdc.acceso.model;

public enum Puesto {
    Desarrollador, Analista;
}
